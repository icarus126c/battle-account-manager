<script lang="ts">
  import { get } from "svelte/store";
  import { route, type Route } from "../stores/nav";
  import { actionBarStatus } from "../stores/fileDrop";
  import { platformActionBusy, triggerPlatformAction } from "../stores/platformPage";
  import { tooltip } from "../lib/actions/tooltip";
  import { collapse, DUR } from "../lib/animation";
  import { t } from "../stores/i18n";
  import { openAlertNoButton } from "../stores/modal";
  import HelpAboutModalBody from "./modals/HelpAboutModalBody.svelte";
  import { capabilities } from "../stores/osCapabilities";
  import { steamPageTab } from "../stores/steamPageTab";
  import { openContextMenu } from "../stores/contextMenu";
  import type { MenuItemDef } from "../stores/contextMenu";
  import { buildFilterMenuItems } from "../lib/filterMenu";
  import { prefetchPage } from "../lib/pageLoaders";
  import { steamGuardActionAccount } from "../stores/steamGuardAction";
  import { emitSteamGuardMenuRequest } from "../lib/steam/steamGuardMenuRequest";
  import "../styles/actionbar.scss";
  // Lazy: neither renders on the home screen, which is the page the startup
  // bundle has to paint, and the platform page chunk pulls them in anyway.
  type Lazy = typeof import("./GameShortcutBar.svelte")["default"] | null;
  type LazySteamBar = typeof import("./SteamGamesAccountBar.svelte")["default"] | null;
  let GameShortcutBar: Lazy = null;
  let SteamGamesAccountBar: LazySteamBar = null;

  $: r = $route;
  $: isPlatformPage = r.page === "platform";
  $: if (isPlatformPage && !GameShortcutBar) {
    void import("./GameShortcutBar.svelte").then((m) => (GameShortcutBar = m.default));
  }
  $: if (isPlatformPage && !SteamGamesAccountBar) {
    void import("./SteamGamesAccountBar.svelte").then((m) => (SteamGamesAccountBar = m.default));
  }
  $: isHomePage = r.page === "home";
  $: platformName = isPlatformPage ? (r as Extract<Route, { page: "platform" }>).platformName : "";
  $: showSaveCurrent = !!platformName && platformName !== "Steam";
  $: steamGuardShortcut = platformName === "Steam" ? $steamGuardActionAccount : null;
  $: steamGamesMode = platformName === "Steam" && $steamPageTab === "games";
  $: isActionBusy = $platformActionBusy.busy;
  let filterBtn: HTMLButtonElement | undefined;

  function prefetchSettingsTarget(): void {
    const cur = get(route);
    if (cur.page === "platform") {
      prefetchPage({ page: "platform-settings", platformName: cur.platformName });
    } else {
      prefetchPage({ page: "settings" });
      void import("../components/GeneralSettingsBlock.svelte");
    }
  }

  function openSettings(): void {
    const cur = get(route);
    if (cur.page === "platform") {
      route.set({ page: "platform-settings", platformName: cur.platformName });
    } else {
      route.set({ page: "settings" });
    }
  }

  function filterMenuItems(): MenuItemDef[] {
    return buildFilterMenuItems(get(route).page === "home" ? "" : platformName);
  }

  function onFilterClick(): void {
    const el = filterBtn;
    if (!el) {
      return;
    }
    const rct = el.getBoundingClientRect();
    // Two rows deep, so the root column is too short to page its own flyouts sensibly.
    openContextMenu(rct.left, rct.bottom + 4, filterMenuItems(), { paginate: false });
  }

  function showHelpModal() {
    void openAlertNoButton({
      title: $t("Modal_Title_Info"),
      bodyComponent: HelpAboutModalBody,
    });
  }

  function openSteamGuardAccounts(): void {
    // With an empty vault there is no account to open the picker on, and that is
    // exactly when the user needs a way to add one.
    if (!steamGuardShortcut) {
      emitSteamGuardMenuRequest({
        action: "add", steamId64: "", accountName: "", displayName: "", pending: false,
      });
      return;
    }
    emitSteamGuardMenuRequest({
      action: "all",
      ...steamGuardShortcut,
      pending: false,
    });
  }
</script>

<!-- The bar is dropped entirely on pages that have no actions. Collapsing its
     height hands the space back to the page instead of snapping it away. -->
<footer
  class="actionbar"
  data-busy={$platformActionBusy.busy}
  transition:collapse={{ duration: DUR.fast }}
>
<span class="actionbar__status">{$actionBarStatus}</span>
  <div class="actionbar__actions">
    {#if isPlatformPage}
      {#if steamGamesMode}
        {#if SteamGamesAccountBar}
          <svelte:component this={SteamGamesAccountBar} />
        {/if}
      {:else}
      <!-- Every action in the bar - scan, run, create, the drop-import - goes
           through winutil shortcut/.lnk code that is ErrUnsupported off Windows. -->
      {#if $capabilities.shortcuts && GameShortcutBar}
        <svelte:component this={GameShortcutBar} platformName={platformName} />
      {/if}
      <button class="btnicontext actionbar__add" type="button" aria-label={$t("Button_AddNew")} use:tooltip={$t("Tooltip_AddNew")} disabled={isActionBusy} on:click={() => triggerPlatformAction("addNew")}
        ><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" aria-hidden="true"
          ><path
            d="M416 208H272V64c0-17.67-14.33-32-32-32h-32c-17.67 0-32 14.33-32 32v144H32c-17.67 0-32 14.33-32 32v32c0 17.67 14.33 32 32 32h144v144c0 17.67 14.33 32 32 32h32c17.67 0 32-14.33 32-32V304h144c17.67 0 32-14.33 32-32v-32c0-17.67-14.33-32-32-32z"
          /></svg
        >{$t("Button_AddNew")}</button
      >
      {#if showSaveCurrent}
        <button
          class="btnicontext actionbar__save"
          type="button"
          aria-label={$t("Button_SaveCurrent")}
          use:tooltip={$t("Tooltip_SaveCurrent")}
          disabled={isActionBusy}
          on:click={() => triggerPlatformAction("saveCurrent")}
          ><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" aria-hidden="true"
            ><path
              d="M64 32C28.7 32 0 60.7 0 96V416c0 35.3 28.7 64 64 64H384c35.3 0 64-28.7 64-64V173.3c0-17-6.7-33.3-18.7-45.3L352 69.3c-12-12-28.3-18.7-45.3-18.7H64zm32 64H288v64H96V96zm160 384H96V288H320V480zm64 0V288h32V480H320z"
            /></svg
          >{$t("Button_SaveCurrent")}</button
        >
      {/if}
      <button
        class="btnicontext actionbar__login"
        type="button"
        aria-label={$t("Button_Login")}
        use:tooltip={$t("Tooltip_Login")}
        disabled={isActionBusy}
        on:click={() => triggerPlatformAction("login")}
        >{$t("Button_Login")}<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" aria-hidden="true">
          <path d="M217.9 105.9L340.7 228.7c7.2 7.2 11.3 17 11.3 27.3s-4.1 20.1-11.3 27.3L217.9 406.1c-6.4 6.4-15 9.9-24 9.9c-18.7 0-33.9-15.2-33.9-33.9V160c0-18.7 15.2-33.9 33.9-33.9c9 0 17.6 3.5 24 9.9z"/></svg>
        </button
      >
      {/if}
      {#if platformName === "Steam"}
        <button
          class="square actionbar__steam-guard"
          type="button"
          aria-label={$t("Context_SteamGuard")}
          use:tooltip={$t("Context_SteamGuard")}
          on:click={openSteamGuardAccounts}
          >
            <svg viewBox="0 0 24 24" aria-hidden="true">
              <path d="M12 2.25 4 5.3v5.8c0 5.05 3.35 9.5 8 10.65 4.65-1.15 8-5.6 8-10.65V5.3L12 2.25Zm0 2.15 6 2.3v4.4c0 3.9-2.45 7.45-6 8.55-3.55-1.1-6-4.65-6-8.55V6.7l6-2.3Z"/>
              <circle cx="9" cy="10" r="1.15"/>
              <circle cx="15" cy="10" r="1.15"/>
              <circle cx="9" cy="14" r="1.15"/>
              <circle cx="15" cy="14" r="1.15"/>
            </svg>
          </button
        >
      {/if}
      <button
        bind:this={filterBtn}
        class="square actionbar__filter"
        type="button"
        aria-label={$t("Filter_Menu")}
        use:tooltip={$t("Filter_Menu")}
        on:click={onFilterClick}
        >
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free v5.15.4 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2026 Fonticons, Inc.--><path d="M487.976 0H24.028C2.71 0-8.047 25.866 7.058 40.971L192 225.941V432c0 7.831 3.821 15.17 10.237 19.662l80 55.98C298.02 518.69 320 507.493 320 487.98V225.941l184.947-184.97C520.021 25.896 509.338 0 487.976 0z"/></svg>
        </button
      >
    {:else}
      {#if isHomePage}
        <button
          bind:this={filterBtn}
          class="square actionbar__filter"
          type="button"
          aria-label={$t("Filter_Menu")}
          use:tooltip={$t("Filter_Menu")}
          on:click={onFilterClick}
          >
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free v5.15.4 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2026 Fonticons, Inc.--><path d="M487.976 0H24.028C2.71 0-8.047 25.866 7.058 40.971L192 225.941V432c0 7.831 3.821 15.17 10.237 19.662l80 55.98C298.02 518.69 320 507.493 320 487.98V225.941l184.947-184.97C520.021 25.896 509.338 0 487.976 0z"/></svg>
          </button
        >
      {/if}
      <button class="btnicontext actionbar__manage" aria-label={$t("Button_ManagePlatforms")} use:tooltip={$t("Tooltip_ManagePlatforms")} on:click={() => route.set({ page: 'manage-platforms'})}><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--!Font Awesome Free v5.15.4 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2026 Fonticons, Inc.--><path d="M416 208H272V64c0-17.67-14.33-32-32-32h-32c-17.67 0-32 14.33-32 32v144H32c-17.67 0-32 14.33-32 32v32c0 17.67 14.33 32 32 32h144v144c0 17.67 14.33 32 32 32h32c17.67 0 32-14.33 32-32V304h144c17.67 0 32-14.33 32-32v-32c0-17.67-14.33-32-32-32z"/></svg>{$t("Button_ManagePlatforms")}</button>
    {/if}
    <button class="square" aria-label={$t("Aria_OpenSettings")} use:tooltip={$t("Tooltip_Settings")} on:mouseenter={prefetchSettingsTarget} on:focus={prefetchSettingsTarget} on:click={openSettings}><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" aria-hidden="true"><!--!Font Awesome Free v5.15.4 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2026 Fonticons, Inc.--><path d="M487.4 315.7l-42.6-24.6c4.3-23.2 4.3-47 0-70.2l42.6-24.6c4.9-2.8 7.1-8.6 5.5-14-11.1-35.6-30-67.8-54.7-94.6-3.8-4.1-10-5.1-14.8-2.3L380.8 110c-17.9-15.4-38.5-27.3-60.8-35.1V25.8c0-5.6-3.9-10.5-9.4-11.7-36.7-8.2-74.3-7.8-109.2 0-5.5 1.2-9.4 6.1-9.4 11.7V75c-22.2 7.9-42.8 19.8-60.8 35.1L88.7 85.5c-4.9-2.8-11-1.9-14.8 2.3-24.7 26.7-43.6 58.9-54.7 94.6-1.7 5.4.6 11.2 5.5 14L67.3 221c-4.3 23.2-4.3 47 0 70.2l-42.6 24.6c-4.9 2.8-7.1 8.6-5.5 14 11.1 35.6 30 67.8 54.7 94.6 3.8 4.1 10 5.1 14.8 2.3l42.6-24.6c17.9 15.4 38.5 27.3 60.8 35.1v49.2c0 5.6 3.9 10.5 9.4 11.7 36.7 8.2 74.3 7.8 109.2 0 5.5-1.2 9.4-6.1 9.4-11.7v-49.2c22.2-7.9 42.8-19.8 60.8-35.1l42.6 24.6c4.9 2.8 11 1.9 14.8-2.3 24.7-26.7 43.6-58.9 54.7-94.6 1.5-5.5-.7-11.3-5.6-14.1zM256 336c-44.1 0-80-35.9-80-80s35.9-80 80-80 80 35.9 80 80-35.9 80-80 80z"/></svg></button>
  <button type="button" class="square" aria-label={$t("Aria_OpenInfo")} use:tooltip={$t("Tooltip_Info")} on:click={showHelpModal}><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512" aria-hidden="true"><!--!Font Awesome Free v5.15.4 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2026 Fonticons, Inc.--><path d="M202.021 0C122.202 0 70.503 32.703 29.914 91.026c-7.363 10.58-5.093 25.086 5.178 32.874l43.138 32.709c10.373 7.865 25.132 6.026 33.253-4.148 25.049-31.381 43.63-49.449 82.757-49.449 30.764 0 68.816 19.799 68.816 49.631 0 22.552-18.617 34.134-48.993 51.164-35.423 19.86-82.299 44.576-82.299 106.405V320c0 13.255 10.745 24 24 24h72.471c13.255 0 24-10.745 24-24v-5.773c0-42.86 125.268-44.645 125.268-160.627C377.504 66.256 286.902 0 202.021 0zM192 373.459c-38.196 0-69.271 31.075-69.271 69.271 0 38.195 31.075 69.27 69.271 69.27s69.271-31.075 69.271-69.271-31.075-69.27-69.271-69.27z"/></svg></button>
  </div>
</footer>
