<script lang="ts" context="module">
  export type { GameStatMetricDTO } from "./PlatformAccountAdapter";
</script>

<script lang="ts" generics="TAccount">
  import { onDestroy, onMount } from "svelte";
  import { get } from "svelte/store";
  import { Events } from "@wailsio/runtime";
  import AccountImagePickOverlay from "./AccountImagePickOverlay.svelte";
  import ReorderPointerGrid from "./ReorderPointerGrid.svelte";
  import TagFilterBar from "./TagFilterBar.svelte";
  import AccountTagBubbles from "./AccountTagBubbles.svelte";
  import AccountLiveSessionIndicator from "./AccountLiveSessionIndicator.svelte";
  import AccountListSkeleton from "./AccountListSkeleton.svelte";
  import SearchOverlay, { type SearchResultRow } from "./SearchOverlay.svelte";
  import { route, previousPage, appBarTitle } from "../stores/nav";
  import {
    platformExeIconUrl,
    platformAction,
    platformActionBusy,
    selectedAccount as selectedAccountStore,
    platformLiveSessionId,
    platformAccountsRefresh,
    requestPlatformAccountsRefresh,
  } from "../stores/platformPage";
  import {
    getPlatformAccountsCache,
    platformAccountCounts,
    setPlatformAccountsCache,
  } from "../stores/platformAccountsCache";
  import { pushToast } from "../stores/toast";
  import { activeModal, openConfirm, openPrompt } from "../stores/modal";
  import { locale, t } from "../stores/i18n";
  import * as BasicService from "../../bindings/TcNo-Acc-Switcher/internal/basic/basicservice.js";
  import { GetPlatformExeIcon } from "../../bindings/TcNo-Acc-Switcher/internal/platform/platformservice.js";
  import { formatToastWithError, formatWailsError } from "../lib/formatWailsError";
  import {
    preflightAdminForPlatform,
    reportLaunchFailure,
  } from "../lib/adminFlow";
  import { contextMenu as ctxMenuAction } from "../lib/actions/contextMenu";
  import { buildFilterMenuItems } from "../lib/filterMenu";
  import { tooltip as tooltipAction } from "../lib/actions/tooltip";
  import { resolveGameStatTooltip } from "../lib/accounts/gameStatTooltip";
  import { contextMenu as contextMenuState, type MenuItemDef } from "../stores/contextMenu";
  import { securityStatus } from "../stores/security";
  import { offlineMode } from "../stores/offlineMode";
  import { avatarSalt, censoredName, censorName, streamerMode } from "../stores/streamerMode";
  import { accountAvatarSrc } from "../lib/accountAvatarSrc";
  import { avatarSwapped, heldAvatarKey, heldAvatarSrc } from "../lib/accounts/heldAvatarSrc";
  import { currentPlatformAvatarEpochs, setPlatformAvatarEpochs } from "../lib/accounts/avatarEpoch";
  import { formatLastLoginForLocale } from "../lib/formatLastLogin";
  import {
    openTagFilterMenu,
    type TagDefRow,
    type TagFilterMode,
  } from "../lib/accountTagsContext";
  import { closeSearchOverlay, searchOverlayCtrl } from "../stores/searchOverlay";
  import { platformListSort, type PlatformSortKind } from "../stores/platformListSort";
  import { actionBarStatus, fileDropInterceptor, accountProfileImageDropActive } from "../stores/fileDrop";
  import { sanitizeHtml } from "../lib/sanitizeHtml";
  import type { GameStatMetricDTO, PlatformAccountAdapter } from "./PlatformAccountAdapter";
  import {
    commandRows,
    isCommandQuery,
    runCommand,
    type CommandPaletteCommand,
  } from "../lib/commandPalette";
  import { reorderItemByCommand, type ReorderCommand } from "../lib/reorderList";
  import {
    getShortcutCommandPaletteState,
    runShortcutCommandPaletteAction,
  } from "./GameShortcutBar.svelte";
  import type { ShortcutReorderCommand } from "../lib/dragReorderShortcuts";
  import "../styles/gamestats.scss";
  import "../styles/platformAccountsShared.scss";

  import {
    mergeListIntoExisting,
    mergeEnrichmentIntoExisting,
    applyLoadedAccounts,
    type ApplyLoadedAccountsState,
  } from "../lib/accounts/mergePipeline";
  import {
    applyAccountPatch,
    buildAccountMap,
    buildAccountSearchRows,
    createImagePickState,
    displayIdsForTagFilter,
    hasActiveAccountTags,
    mergeGameStatsByAccount,
    sortAccountIds,
    type AccountImagePickState,
    type SearchHayCache,
  } from "../lib/accounts/accountPageModel";
  import { buildSharedItems, type ContextMenuContext } from "../lib/accounts/contextMenuBuilder";
  import { fileDropIntercept, type FileDropContext } from "../lib/accounts/fileDropHandler";
  import {
    createLatestRequestGuard,
    registerWindowFocusAccountRefresh,
  } from "../lib/accounts/windowFocusRefresh";
  import {
    loadTagDefs,
    refreshGameStatsMarkup,
    refreshGameStatsSupport,
    openGameStatsModal,
  } from "../lib/accounts/gameStatsWorker";
  import {
    swapToLogin as swapToLoginFn,
    handlePlatformActionKind,
    runPlatformActionLocked,
    type AccountActionsContext,
  } from "../lib/accounts/accountActions";

  export let name: string;
  export let adapter: PlatformAccountAdapter<TAccount>;

  const SEARCH_MAX = 5;
  type BasicServiceWithTagExpiry = typeof BasicService & {
    PruneExpiredTags?: (platformKey: string) => Promise<boolean>;
  };
  const tagExpiryService = BasicService as BasicServiceWithTagExpiry;

  let accounts: TAccount[] = [];
  let accountIds: string[] = [];
  $: accountMap = buildAccountMap(accounts, adapter);
  const searchHayCache: SearchHayCache = new Map();
  let accountsLoading = false;
  let tagDefsLoading = false;
  let loadError = "";
  let selectedId = "";
  let isActionBusyValue = false;

  let refreshTimers: ReturnType<typeof setTimeout>[] = [];
  // Deliberately a plain holder rather than component state: the reactive block
  // that calls scheduleTagExpiryPrune reaches this handle through a function,
  // which both reads and writes it. Svelte 5 tracks those runtime reads as
  // dependencies of the block, so a reactive `let` re-triggered the block on
  // every write and hung the page whenever a tag carried an expiry.
  const tagExpiry: { timer: ReturnType<typeof setTimeout> | undefined } = { timer: undefined };
  let tagExpiryPruneRunning = false;
  let acclistEl: HTMLDivElement | undefined;
  let overlayQuery = "";
  let overlayQueryDebounceTimer: ReturnType<typeof setTimeout> | null = null;
  let debouncedOverlayQuery = "";
  let avatarEpoch: Record<string, number> = currentPlatformAvatarEpochs(name);
  let rowVersions: Record<string, number> = {};
  let tagDefs: TagDefRow[] = [];
  let tagFilterMode: TagFilterMode = { kind: "all" };
  let imagePick: AccountImagePickState = { open: false, accountId: "", displayName: "", manual: false };
  let fileDragHoverRowId = "";
  let offPlatformAction: (() => void) | undefined;
  let offAccountsRefresh: (() => void) | undefined;
  let offUpdateEvent: (() => void) | undefined;
  const offExtraUpdateEvents: (() => void)[] = [];
  let offGameStatsUpdated: (() => void) | undefined;
  let offSort: (() => void) | undefined;
  let offWindowFocus: (() => void) | undefined;
  let lastHandledActionId = 0;
  let lastHandledSortId = 0;
  const accountLoadGuard = createLatestRequestGuard();

  let gameStatsByAccount: Record<string, Record<string, Record<string, GameStatMetricDTO>>> = {};
  let hasGameStatsSupport = false;

  $: so = $searchOverlayCtrl;
  $: appBarTitle.set(name || "TcNo Account Switcher");
  $: isActionBusy = isActionBusyValue;

  $: {
    const q = overlayQuery;
    if (overlayQueryDebounceTimer) clearTimeout(overlayQueryDebounceTimer);
    overlayQueryDebounceTimer = setTimeout(() => { debouncedOverlayQuery = q; }, 150);
  }

  // Only write when the route is not already here. This used to set a brand-new
  // route object on every pass; the store flows back down through App as our
  // `name` prop, so under Svelte 5 that fed itself and spun the whole page's
  // reactive graph forever.
  $: if (name) {
    const cur = get(route);
    const alreadyHere = cur.page === "platform" && cur.platformName === name;
    if (!alreadyHere) {
      route.set({ page: "platform", platformName: name });
    }
  }

  $: commandMode = isCommandQuery(overlayQuery);
  $: searchPrimary = commandMode
    ? commandRows(overlayQuery, buildPlatformCommands(), get(t)("Search_Section_Command"))
    : buildAccountRows(debouncedOverlayQuery, avatarEpoch);

  $: selectedAccountStore.set({
    platformKey: name,
    uniqueId: selectedId,
    displayName: accountById(selectedId) ? adapter.name(accountById(selectedId)!) : "",
    accountLogin: accountById(selectedId) ? adapter.accountLogin(accountById(selectedId)!) : "",
  });

  $: tagFilterBarLabel =
    tagFilterMode.kind === "all"
      ? $t("Tags_All")
      : tagFilterMode.kind === "untagged"
        ? $t("Tags_Filter_Untagged")
        : tagFilterMode.kind === "notTag"
          ? $t("Tags_Filter_WithoutName", { name: tagFilterMode.name })
          : tagFilterMode.name;

  $: displayIds = displayIdsForTagFilter(accountIds, accountMap, adapter, tagFilterMode);

  $: reorderDisabled = tagFilterMode.kind !== "all";

  $: knownAccountCount = $platformAccountCounts[name];
  $: hasActiveTags = hasActiveAccountTags(accounts, adapter);
  $: {
    if (!hasActiveTags && tagFilterMode.kind !== "all") {
      tagFilterMode = { kind: "all" };
    }
  }
  $: {
    void accounts;
    void tagDefs;
    void name;
    void adapter;
    scheduleTagExpiryPrune(soonestLoadedTagExpiryMs());
  }
  $: skeletonCount =
    knownAccountCount !== undefined
      ? Math.min(24, Math.max(0, knownAccountCount))
      : 3;

  $: {
    if (selectedId && displayIds.length > 0 && !displayIds.includes(selectedId)) {
      selectedId = "";
      touchStatus();
    }
  }

  function accountById(id: string): TAccount | undefined {
    return accountMap.get(id);
  }

  function slotKey(x: string | null | undefined): string {
    return x ?? "";
  }

  function compactText(value: string | null | undefined): string {
    return String(value ?? "").replace(/\s+/g, " ").trim();
  }

  /* Feeds the screen reader, the action bar and modal titles. Censored for the
     same reason the tile is: a narrator reading the SteamID out is still a leak,
     and these strings surface in tooltips a capture card picks up. */
  function accountDisplayLabel(acc: TAccount): string {
    const name = compactText(adapter.name(acc));
    if (name) return censorName(name, get(streamerMode));
    if (get(streamerMode)) return get(t)("StreamerMode_HiddenAccount");
    return compactText(adapter.accountLogin(acc)) || adapter.id(acc);
  }

  function accountA11yDescription(acc: TAccount, id: string): string {
    const tr = get(t);
    const parts: string[] = [];
    const label = accountDisplayLabel(acc);
    if (selectedId === id) parts.push(tr("Status_SelectedAccount", { name: label }));
    if (adapter.currentSession(acc)) parts.push(tr("Tooltip_CurrentAccount"));
    if (adapter.savedDataBroken?.(acc)) parts.push(tr("Security_AccountDataBroken"));

    // The name colour is the only visual cue for a ban, so it has to be spoken too.
    const nameStatus = adapter.nameStatus?.(acc);
    if (nameStatus) parts.push(nameStatus.label);

    const tags = (adapter.tags(acc) ?? []).map((tag) => compactText(tag.name)).filter(Boolean);
    if (tags.length > 0) parts.push(`${tr("Tags_Section")}: ${tags.join(", ")}`);

    if (adapter.shouldShowNote(acc)) {
      const note = compactText(adapter.note(acc));
      if (note) parts.push(`${tr("Notes")}: ${note}`);
    }

    if (adapter.shouldShowLastUsed(acc)) {
      const lastUsed = compactText(formatLastLoginForLocale(adapter.lastUsed(acc), get(locale)));
      if (lastUsed) parts.push(`${tr("Filter_Sort_LastUsed")}: ${lastUsed}`);
    }

    for (const line of adapter.extraA11yStatus?.(acc) ?? []) {
      const spoken = compactText(line);
      if (spoken) parts.push(spoken);
    }

    return parts.join(". ");
  }

  function accountGridLabel(id: string): string {
    const acc = accountById(id);
    if (!acc) return id;
    const label = accountDisplayLabel(acc);
    const description = accountA11yDescription(acc, id);
    return description ? `${label}. ${description}` : label;
  }

  function touchStatus(): void {
    if (isActionBusy) return;
    const acc = accountById(selectedId);
    actionBarStatus.set(acc ? $t("Status_SelectedAccount", { name: accountDisplayLabel(acc) }) : "");
  }

  function clearSelection(): void {
    if (!selectedId) return;
    selectedId = "";
    touchStatus();
  }

  function onAccountsAreaClick(e: MouseEvent): void {
    const target = e.target as HTMLElement | null;
    if (!target) return;
    if (target.closest("[data-dnd-cell]")) return;
    clearSelection();
  }

  function onWindowKeyDown(e: KeyboardEvent): void {
    if (e.key === "F5") {
      // Nothing else claims F5: Wails turns WebView2's own accelerator keys off,
      // and App.svelte's global handler ignores any key whose name is longer
      // than one character. So the accounts page is free to mean "fetch it all
      // again" by it, which is what everyone presses F5 expecting.
      if (get(securityStatus).appLocked) return;
      if (get(activeModal) || get(contextMenuState) || get(searchOverlayCtrl).open) return;
      if (imagePick.open) return;
      e.preventDefault();
      void refreshAccounts();
      return;
    }
    if (e.key !== "Escape") return;
    if (get(activeModal)) return;
    if (imagePick.open) { e.preventDefault(); closeImagePick(); return; }
    clearSelection();
  }

  function onItemClick(e: CustomEvent<{ id: string }>): void {
    selectedId = e.detail.id;
    touchStatus();
  }

  const REFRESH_DEBOUNCE_MS = 300;

  function scheduleAccountsRefresh(): void {
    for (const t of refreshTimers) clearTimeout(t);
    refreshTimers = [];
    refreshTimers.push(
      setTimeout(() => {
        refreshTimers = [];
        void loadAccounts();
      }, REFRESH_DEBOUNCE_MS),
    );
  }

  /**
   * Writes go to the shared store as well as the local copy: other views of these
   * accounts would otherwise sit on an older counter and ask for an older URL.
   * The local copy stays because callers read it back in the same tick.
   */
  function setAvatarEpoch(next: Record<string, number>): void {
    avatarEpoch = next;
    setPlatformAvatarEpochs(name, next);
  }

  function bumpAvatarEpoch(id: string): void {
    const uid = id.trim();
    if (!uid) return;
    setAvatarEpoch({ ...avatarEpoch, [uid]: (avatarEpoch[uid] ?? 0) + 1 });
  }

  function getAccountActionsCtx(): AccountActionsContext {
    return {
      name,
      adapter,
      get selectedId() { return selectedId; },
      get isActionBusyValue() { return isActionBusyValue; },
      accountById,
      scheduleAccountsRefresh,
      touchStatus,
      setIsActionBusy: (v: boolean) => { isActionBusyValue = v; },
    };
  }

  function createFileDropCtx(): FileDropContext {
    return {
      adapter,
      get imagePick() { return imagePick; },
      get fileDragHoverRowId() { return fileDragHoverRowId; },
      tr: get(t),
      loadAccounts,
      bumpAvatarEpoch,
      closeImagePick,
      clearFileDragHover: () => { fileDragHoverRowId = ""; },
    };
  }

  async function loadTagDefsInternal(): Promise<void> {
    tagDefsLoading = true;
    try {
      tagDefs = await loadTagDefs(name);
    } finally {
      tagDefsLoading = false;
    }
  }

  async function refreshGameStatsMarkupInternal(acctIds: string[], mergePatch = false): Promise<void> {
    // An empty id list resolves to {}, which would blank every row's stats.
    if (acctIds.length === 0) return;
    const next = await refreshGameStatsMarkup(name, acctIds);
    gameStatsByAccount = mergePatch
      ? mergeGameStatsByAccount(gameStatsByAccount, next)
      : next;
  }

  async function refreshGameStatsSupportInternal(): Promise<void> {
    hasGameStatsSupport = await refreshGameStatsSupport(name);
  }


  async function swapToLogin(): Promise<void> {
    const acc = accountById(selectedId);
    if (acc && adapter.savedDataBroken?.(acc)) {
      pushToast({ type: "error", message: $t("Security_AccountDataBroken"), duration: 6000 });
      return;
    }
    await runPlatformActionLocked(async () => {
      await swapToLoginFn(getAccountActionsCtx());
    }, getAccountActionsCtx());
  }

  function applyPlatformSort(kind: PlatformSortKind): void {
    const ids = sortAccountIds(accountIds, accountById, adapter, kind);
    if (!ids) return;
    accountIds = ids;
    adapter.saveOrder(ids).catch(() => {});
  }

  function accountDisplayName(id: string): string {
    const acc = accountById(id);
    return acc ? adapter.name(acc) || adapter.id(acc) : id;
  }

  async function applyAccountReorderCommand(id: string, command: ReorderCommand): Promise<void> {
    if (reorderDisabled) return;
    const result = reorderItemByCommand(accountIds, id, command);
    if (!result.moved) return;
    const previous = accountIds;
    accountIds = result.items;
    selectedId = id;
    touchStatus();
    try {
      await adapter.saveOrder(result.items);
      pushToast({
        type: "success",
        message: $t("Toast_MovedItemPosition", {
          item: accountDisplayName(id),
          position: result.position,
          total: result.total,
        }),
        duration: 3500,
      });
    } catch (e) {
      accountIds = previous;
      pushToast({ type: "error", message: formatToastWithError($t("Toast_SaveFailed"), e), duration: 8000 });
    }
  }

  function accountReorderMenu(id: string): MenuItemDef {
    const index = accountIds.indexOf(id);
    const canMoveLeft = !reorderDisabled && index > 0;
    const canMoveRight = !reorderDisabled && index >= 0 && index < accountIds.length - 1;
    return {
      label: $t("Context_Reorder"),
      children: [
        { label: $t("Context_MoveLeft"), disabled: !canMoveLeft, action: () => { void applyAccountReorderCommand(id, "left"); } },
        { label: $t("Context_MoveRight"), disabled: !canMoveRight, action: () => { void applyAccountReorderCommand(id, "right"); } },
        { label: $t("Context_MoveToStart"), disabled: !canMoveLeft, action: () => { void applyAccountReorderCommand(id, "start"); } },
        { label: $t("Context_MoveToEnd"), disabled: !canMoveRight, action: () => { void applyAccountReorderCommand(id, "end"); } },
      ],
    };
  }

  function onTagFilterBarClick(ev: Event): void {
    openTagFilterMenu({
      ev: ev as MouseEvent,
      tagDefs,
      tr: get(t),
      onPick: (mode) => { tagFilterMode = mode; },
    });
  }

  function hasFilesDragType(ev: DragEvent): boolean {
    const types = ev.dataTransfer?.types;
    return !!(types && Array.from(types as unknown as Iterable<string>).includes("Files"));
  }

  function onAccDragOver(ev: DragEvent, rid: string): void {
    if (!hasFilesDragType(ev)) return;
    ev.preventDefault();
    fileDragHoverRowId = rid;
  }

  function onAccDragLeave(ev: DragEvent, rid: string): void {
    if (!hasFilesDragType(ev)) return;
    const rel = ev.relatedTarget as Node | null;
    const cur = ev.currentTarget as HTMLElement | null;
    if (!rel || !cur?.contains(rel)) {
      if (fileDragHoverRowId === rid) fileDragHoverRowId = "";
    }
  }

  function onAccListDragLeave(ev: DragEvent): void {
    if (!hasFilesDragType(ev)) return;
    const rel = ev.relatedTarget as Node | null;
    if (!acclistEl || rel === null || !acclistEl.contains(rel)) {
      fileDragHoverRowId = "";
    }
  }

  function closeImagePick(): void {
    imagePick = { open: false, accountId: "", displayName: "", manual: false };
    fileDragHoverRowId = "";
  }

  function openImagePick(rowId: string): void {
    imagePick = createImagePickState(rowId, accountById(rowId), adapter);
  }

  async function applyImageFromOverlay(path: string): Promise<void> {
    const id = imagePick.accountId.trim();
    if (!id) return;
    await adapter.changeImage(id, path);
    await loadAccounts();
    bumpAvatarEpoch(id);
    pushToast({ type: "success", message: $t("Toast_AccountSaved"), duration: 4000 });
  }

  async function removeImageFromOverlay(): Promise<void> {
    const id = imagePick.accountId.trim();
    if (!id) return;
    await adapter.clearManualImage(id);
    await loadAccounts();
    bumpAvatarEpoch(id);
    scheduleAccountsRefresh();
    pushToast({ type: "success", message: $t("Toast_AccountSaved"), duration: 4000 });
  }

  function visibleAccountIds(): string[] {
    return displayIds.filter((id) => !!accountById(id));
  }

  function parseTagExpiryMs(value: string | undefined): number | null {
    if (!value) return null;
    const parsed = Date.parse(value);
    return Number.isNaN(parsed) ? null : parsed;
  }

  function minExpiryMs(current: number | null, value: string | undefined): number | null {
    const expiryMs = parseTagExpiryMs(value);
    if (expiryMs === null) return current;
    return current === null ? expiryMs : Math.min(current, expiryMs);
  }

  function soonestLoadedTagExpiryMs(): number | null {
    let soonest: number | null = null;
    for (const tag of tagDefs) {
      soonest = minExpiryMs(soonest, tag.expiresAt);
    }
    for (const account of accounts) {
      for (const tag of adapter.tags(account) ?? []) {
        soonest = minExpiryMs(soonest, tag.expiresAt);
      }
    }
    return soonest;
  }

  function clearTagExpiryTimer(): void {
    if (!tagExpiry.timer) return;
    clearTimeout(tagExpiry.timer);
    tagExpiry.timer = undefined;
  }

  function scheduleTagExpiryPrune(nextExpiryMs: number | null): void {
    clearTagExpiryTimer();
    const platformKey = name.trim();
    if (!platformKey || nextExpiryMs === null || !tagExpiryService.PruneExpiredTags) return;
    tagExpiry.timer = setTimeout(() => {
      void pruneExpiredTagsForPlatform(platformKey);
    }, Math.max(0, nextExpiryMs - Date.now()));
  }

  async function pruneExpiredTagsForPlatform(platformKey: string): Promise<void> {
    const prune = tagExpiryService.PruneExpiredTags;
    if (!prune || tagExpiryPruneRunning) return;
    tagExpiryPruneRunning = true;
    try {
      const changed = await prune(platformKey);
      if (changed) {
        tagFilterMode = { kind: "all" };
        await loadAccounts();
        await loadTagDefsInternal();
      }
    } catch (e) {
      pushToast({ type: "error", message: formatToastWithError($t("Toast_SaveFailed"), e), duration: 8000 });
    } finally {
      tagExpiryPruneRunning = false;
    }
  }

  async function clearAccountTagsForPlatform(): Promise<void> {
    const ok = await openConfirm({
      title: $t("Command_ClearAccountTags"),
      body: $t("Command_ClearAccountTagsConfirm", { platform: name }),
      positiveLabel: $t("Command_ClearAccountTags"),
      negativeLabel: $t("Button_Cancel"),
      style: "okcancel",
    });
    if (!ok) return;
    try {
      await BasicService.ClearAccountTags(name);
      tagFilterMode = { kind: "all" };
      await loadAccounts();
      await loadTagDefsInternal();
      pushToast({ type: "success", message: $t("Toast_AccountTagsCleared"), duration: 4000 });
    } catch (e) {
      pushToast({ type: "error", message: formatToastWithError($t("Toast_SaveFailed"), e), duration: 8000 });
    }
  }

  async function tagVisibleAccounts(): Promise<void> {
    const ids = visibleAccountIds();
    if (ids.length === 0) {
      pushToast({ type: "info", message: $t("Toast_NoVisibleAccounts"), duration: 4000 });
      return;
    }
    const tagName = await openPrompt({
      title: $t("Command_TagVisibleAccounts"),
      body: $t("Command_TagVisibleAccountsPrompt", { count: ids.length }),
      positiveLabel: $t("Tags_Add"),
      negativeLabel: $t("Button_Cancel"),
    });
    const trimmed = String(tagName ?? "").trim();
    if (tagName === null || !trimmed) return;
    try {
      await BasicService.AddTagToAccounts(name, ids, trimmed);
      await loadAccounts();
      await loadTagDefsInternal();
      pushToast({
        type: "success",
        message: $t("Toast_TaggedVisibleAccounts", { count: ids.length, tag: trimmed }),
        duration: 4000,
      });
    } catch (e) {
      pushToast({ type: "error", message: formatToastWithError($t("Toast_SaveFailed"), e), duration: 8000 });
    }
  }

  async function clearAllProfileImages(): Promise<void> {
    const ok = await openConfirm({
      title: $t("Command_ClearAllImages"),
      body: $t("Command_ClearAllImagesConfirm", { platform: name }),
      positiveLabel: $t("Command_ClearAllImages"),
      negativeLabel: $t("Button_Cancel"),
      style: "okcancel",
    });
    if (!ok) return;
    try {
      await BasicService.ClearAllBasicProfileImages(name);
      requestPlatformAccountsRefresh(name);
      for (const id of accountIds) bumpAvatarEpoch(id);
      await loadAccounts();
      pushToast({ type: "success", message: $t("Toast_ProfileImagesCleared"), duration: 4000 });
    } catch (e) {
      pushToast({ type: "error", message: formatToastWithError($t("Toast_SaveFailed"), e), duration: 8000 });
    }
  }

  async function refreshAllProfileImages(): Promise<void> {
    try {
      if (adapter.refreshAllProfileImages) {
        await adapter.refreshAllProfileImages();
      } else {
        await BasicService.RefreshAllBasicProfileImages(name);
      }
      requestPlatformAccountsRefresh(name);
      for (const id of accountIds) bumpAvatarEpoch(id);
      await loadAccounts();
      pushToast({ type: "success", message: $t("Toast_ImagesRefreshing"), duration: 5000 });
    } catch (e) {
      pushToast({ type: "error", message: formatToastWithError($t("Toast_SaveFailed"), e), duration: 8000 });
    }
  }

  let refreshingEverything = false;

  /**
   * Everything the page shows that came from somewhere else: avatars, names,
   * ban state, and every enabled game's stats. This is what F5 means here.
   *
   * The platform's own half goes through the adapter - Steam drops its cached
   * profile XML, miniprofile HTML and automated avatars so the next fetch has to
   * ask Steam again. Game stats are refreshed for every platform, ignoring the
   * per-game cache lifetime, because "I pressed refresh and the number did not
   * move" is the whole reason someone presses it.
   */
  async function refreshAccounts(): Promise<void> {
    if (refreshingEverything) return;
    refreshingEverything = true;
    try {
      if (adapter.refreshAccounts) {
        await adapter.refreshAccounts();
      } else {
        await BasicService.RefreshAllBasicProfileImages(name);
      }
      await BasicService.RefreshAllGameStats(name);
      requestPlatformAccountsRefresh(name);
      for (const id of accountIds) bumpAvatarEpoch(id);
      await loadAccounts();
      pushToast({ type: "success", message: $t("Toast_RefreshingAccounts"), duration: 5000 });
    } catch (e) {
      pushToast({ type: "error", message: formatToastWithError($t("Toast_RefreshAccountsFailed"), e), duration: 8000 });
    } finally {
      refreshingEverything = false;
    }
  }

  // Game stats markup and tag defs live only in this component, so a remount starts
  // with neither. The account cache outlives the page, so a reload after navigating
  // back finds nothing changed - this tracks whether the fetch has happened at all,
  // rather than leaving every row stat-less and untagged until the list next changes.
  let nonCriticalWorkStarted = false;

  function deferNonCriticalAccountWork(ids: string[]): void {
    if (ids.length === 0) return;
    nonCriticalWorkStarted = true;
    void loadTagDefsInternal();
    void refreshGameStatsMarkupInternal(ids);
    void BasicService.StartGameStatsRefresh(name);
  }

  async function loadAccounts(): Promise<void> {
    const loadRequest = accountLoadGuard.begin();
    loadError = "";
    accountsLoading = true;

    const cached = getPlatformAccountsCache(name);
    if (cached && cached.accounts.length > 0) {
      accounts = cached.accounts as TAccount[];
      accountIds = [...cached.accountIds];
      const liveRow = accounts.find((r) => adapter.currentSession(r));
      platformLiveSessionId.set({ platformKey: name, uniqueId: liveRow ? adapter.id(liveRow) : "" });
      touchStatus();
    }

    const prevById = new Map(accounts.map((a) => [adapter.id(a), a]));
    const hadCachedAccounts = !!(cached && cached.accounts.length > 0);
    try {
      const list = await adapter.loadAccountsList();
      if (!accountLoadGuard.isCurrent(loadRequest)) return;
      const mergedList = mergeListIntoExisting(adapter, accounts, list);
      const state: ApplyLoadedAccountsState<TAccount> = {
        avatarEpoch, accounts, accountIds, selectedId,
      };
      const listChanged = applyLoadedAccounts(adapter, name, mergedList, prevById, state, touchStatus);
      ({ accounts, accountIds, selectedId } = state);
      setAvatarEpoch(state.avatarEpoch);
      accountsLoading = false;
      if (listChanged || !nonCriticalWorkStarted) deferNonCriticalAccountWork(accountIds);

      void (async () => {
        try {
          const enrich = await adapter.loadAccountsEnrichment();
          if (!accountLoadGuard.isCurrent(loadRequest)) return;
          const enrichPrev = new Map(accounts.map((a) => [adapter.id(a), a]));
          const merged = mergeEnrichmentIntoExisting(adapter, accounts, enrich);
          const enrichState: ApplyLoadedAccountsState<TAccount> = {
            avatarEpoch, accounts, accountIds, selectedId,
          };
          const enrichChanged = applyLoadedAccounts(adapter, name, merged, enrichPrev, enrichState, touchStatus);
          ({ accounts, accountIds, selectedId } = enrichState);
          setAvatarEpoch(enrichState.avatarEpoch);
          if (enrichChanged || !nonCriticalWorkStarted) deferNonCriticalAccountWork(accountIds);
          await adapter.onAfterLoad?.(accounts, { hadCachedAccounts, enrichChanged });
        } catch {
          if (!accountLoadGuard.isCurrent(loadRequest)) return;
          await adapter.onAfterLoad?.(accounts, { hadCachedAccounts, enrichChanged: false });
        }
      })();
    } catch (e) {
      if (!accountLoadGuard.isCurrent(loadRequest)) return;
      accountsLoading = false;
      if (!cached || cached.accounts.length === 0) {
        loadError = formatWailsError(e) || String(e);
        accounts = []; accountIds = []; selectedId = "";
        gameStatsByAccount = {};
        actionBarStatus.set("");
        platformLiveSessionId.set({ platformKey: "", uniqueId: "" });
      }
    }
  }

  function applyPatchFromEvent(raw: unknown): void {
    const patch = adapter.buildPatch(raw);
    const targetId = adapter.patchTargetId(patch);
    const prev = accountById(targetId);
    if (!prev) return;
    applyRowUpdate(targetId, adapter.applyPatch(patch, prev));
  }

  function applyRowUpdate(targetId: string, next: TAccount): void {
    const result = applyAccountPatch(accounts, rowVersions, avatarEpoch, adapter, targetId, next);
    if (!result.changed) return;
    accounts = result.accounts;
    rowVersions = result.rowVersions;
    setAvatarEpoch(result.avatarEpoch);
    setPlatformAccountsCache(name, { accounts, accountIds });
    if (targetId === selectedId) touchStatus();
  }

  function buildAccountRows(q: string, epochs: Record<string, number>): SearchResultRow[] {
    return buildAccountSearchRows({
      accounts,
      rows: adapter,
      query: q,
      max: SEARCH_MAX,
      rowVersions,
      avatarEpoch: epochs,
      searchHayCache,
      offlineMode: get(offlineMode),
      profileFallback: adapter.profileFallback,
      platformKey: adapter.platformKey,
      streamer: get(streamerMode),
      avatarSalt: get(avatarSalt),
      accountBadge: get(t)("Search_Section_Account"),
    });
  }

  function buildPlatformCommands(): CommandPaletteCommand[] {
    const tr = get(t);
    const commands: CommandPaletteCommand[] = [
      {
        id: "login",
        title: tr("Command_LoginSelected"),
        run: () => handlePlatformActionKind("login", getAccountActionsCtx()),
      },
      {
        id: "add-new",
        title: tr("Command_AddNewAccount"),
        run: () => handlePlatformActionKind("addNew", getAccountActionsCtx()),
      },
      {
        id: "refresh-accounts",
        title: tr("Command_RefreshAccounts"),
        run: () => refreshAccounts(),
      },
      {
        id: "clear-account-tags",
        title: tr("Command_ClearAccountTags"),
        run: () => clearAccountTagsForPlatform(),
      },
      {
        id: "tag-visible-accounts",
        title: tr("Command_TagVisibleAccounts"),
        run: () => tagVisibleAccounts(),
      },
      {
        id: "clear-all-images",
        title: tr("Command_ClearAllImages"),
        run: () => clearAllProfileImages(),
      },
      {
        id: "refresh-all-images",
        title: tr("Command_RefreshAllImages"),
        run: () => refreshAllProfileImages(),
      },
      {
        id: "move-selected-account-left",
        title: tr("Command_MoveSelectedAccountLeft"),
        run: () => { if (selectedId) void applyAccountReorderCommand(selectedId, "left"); },
      },
      {
        id: "move-selected-account-right",
        title: tr("Command_MoveSelectedAccountRight"),
        run: () => { if (selectedId) void applyAccountReorderCommand(selectedId, "right"); },
      },
      {
        id: "move-selected-account-start",
        title: tr("Command_MoveSelectedAccountStart"),
        run: () => { if (selectedId) void applyAccountReorderCommand(selectedId, "start"); },
      },
      {
        id: "move-selected-account-end",
        title: tr("Command_MoveSelectedAccountEnd"),
        run: () => { if (selectedId) void applyAccountReorderCommand(selectedId, "end"); },
      },
      {
        id: "platform-settings",
        title: tr("Command_OpenPlatformSettings", { platform: name }),
        run: () => route.set({ page: "platform-settings", platformName: name }),
      },
      {
        id: "home",
        title: tr("Command_GoHome"),
        run: () => route.set({ page: "home" }),
      },
    ];
    const shortcutState = getShortcutCommandPaletteState(name);
    const addShortcutCommand = (fileName: string, displayName: string, command: ShortcutReorderCommand, title: string) => {
      commands.push({
        id: `shortcut:${command}:${fileName}`,
        title,
        run: () => runShortcutCommandPaletteAction(name, fileName, command),
      });
    };
    const addShortcutCommandsForZone = (
      items: { fileName: string; displayName: string }[],
      zone: "pinned" | "dropdown",
    ) => {
      items.forEach((item, index) => {
        const label = item.displayName || item.fileName;
        if (index > 0) {
          addShortcutCommand(item.fileName, label, "left", tr("Command_MoveShortcutLeft", { name: label }));
        }
        if (index < items.length - 1) {
          addShortcutCommand(item.fileName, label, "right", tr("Command_MoveShortcutRight", { name: label }));
        }
        if (zone === "pinned") {
          addShortcutCommand(item.fileName, label, "unpin", tr("Command_UnpinShortcut", { name: label }));
          addShortcutCommand(
            item.fileName,
            label,
            "move-to-dropdown",
            tr("Command_MoveShortcutToDropdown", { name: label }),
          );
        } else {
          addShortcutCommand(item.fileName, label, "pin", tr("Command_PinShortcut", { name: label }));
          addShortcutCommand(
            item.fileName,
            label,
            "move-to-pinned",
            tr("Command_MoveShortcutToPinned", { name: label }),
          );
        }
      });
    };
    addShortcutCommandsForZone(shortcutState.pinned, "pinned");
    addShortcutCommandsForZone(shortcutState.dropdown, "dropdown");
    if (name !== "Steam") {
      commands.splice(2, 0, {
        id: "save-current",
        title: tr("Command_SaveCurrentAccount"),
        run: () => handlePlatformActionKind("saveCurrent", getAccountActionsCtx()),
      });
    }
    return commands;
  }

  async function onSearchPick(ev: CustomEvent<SearchResultRow>): Promise<void> {
    const row = ev.detail;
    closeSearchOverlay();
    if (row.key.startsWith("cmd:")) {
      runCommand(buildPlatformCommands(), row.key);
      return;
    }
    if (row.key.startsWith("a:")) {
      const id = row.key.slice(2);
      selectedId = id;
      touchStatus();
      await swapToLogin();
    }
    if (row.key.startsWith("g:") && adapter.gameSearchRows) {
      const appId = row.key.slice(2);
      if (!selectedId) {
        pushToast({ type: "error", message: $t("Toast_NoValidSteamId"), duration: 5000 });
        return;
      }
      try {
        if (adapter.loginAndLaunchGame) await adapter.loginAndLaunchGame(selectedId, appId);
        scheduleAccountsRefresh();
        pushToast({
          type: "success",
          message: $t("Toast_StartedGame", { program: row.title }),
          duration: 4000,
        });
      } catch (e) { await reportLaunchFailure(e, name); }
    }
  }

  function ctxMenu(rowId: string): () => MenuItemDef[] {
    return () => {
      const acc = accountById(rowId);
      if (!acc) return [];
      const ctx: ContextMenuContext = {
        name,
        adapter,
        get isActionBusy() { return isActionBusyValue; },
        get hasGameStatsSupport() { return hasGameStatsSupport; },
        tr: get(t),
        get tagDefs() { return tagDefs; },
        openImagePick,
        swapToLogin,
        loadAccounts,
        scheduleAccountsRefresh,
        loadTagDefs: loadTagDefsInternal,
        openGameStatsModal: (rid: string) => openGameStatsModal(rid, adapter, name, accountById, () => {
          // Enabling or disabling a game leaves the account list identical, so the
          // reload alone would never refetch this row's stats.
          void refreshGameStatsMarkupInternal([rid], true);
          void loadAccounts();
        }),
        onSelectedIdChanged: (id: string) => { selectedId = id; touchStatus(); },
      };
      const shared = buildSharedItems(acc, rowId, ctx);
      return [...adapter.buildMenu(acc, shared), accountReorderMenu(rowId)];
    };
  }

  /**
   * Right-click on empty space. The row menu stops propagation, so this only
   * fires where no account was clicked. Every platform gets the action bar's
   * filter entries here, followed by anything the adapter adds (Steam's New
   * Account).
   */
  function backgroundMenu(): MenuItemDef[] {
    if (isActionBusyValue) return [];
    return [...buildFilterMenuItems(name), ...(adapter.buildBackgroundMenu?.() ?? [])];
  }

  onMount(() => {
    previousPage.set({ page: "home" });
    void preflightAdminForPlatform(name);
    void refreshGameStatsSupportInternal();
    void loadAccounts();
    void GetPlatformExeIcon(name).then((u: string) => platformExeIconUrl.set(u ?? ""));

    offSort = platformListSort.subscribe((sig) => {
      if (!sig || sig.id <= lastHandledSortId) return;
      lastHandledSortId = sig.id;
      applyPlatformSort(sig.kind);
    });

    offPlatformAction = platformAction.subscribe((v) => {
      if (!v || v.id === lastHandledActionId) return;
      lastHandledActionId = v.id;
      void handlePlatformActionKind(v.kind, getAccountActionsCtx());
    });

    offAccountsRefresh = platformAccountsRefresh.subscribe((p) => {
      if (p.seq === 0 || p.platformKey !== name) return;
      scheduleAccountsRefresh();
    });

    offUpdateEvent = Events.On(adapter.updateEventName, (ev) => {
      applyPatchFromEvent(ev.data);
    });

    for (const extra of adapter.extraUpdateEvents ?? []) {
      offExtraUpdateEvents.push(Events.On(extra.name, (ev) => {
        const targetId = extra.targetId(ev.data);
        const prev = targetId ? accountById(targetId) : undefined;
        if (!prev) return;
        applyRowUpdate(targetId, extra.apply(ev.data, prev));
      }));
    }

    offGameStatsUpdated = Events.On("basic-game-stats-updated", (ev) => {
      const p = ev.data as { platformKey?: string; uniqueId?: string };
      if ((p.platformKey ?? "").trim() !== name.trim()) return;
      const uid = (p.uniqueId ?? "").trim();
      if (uid) void refreshGameStatsMarkupInternal([uid], true);
    });

    if (adapter.refreshOnWindowFocus) {
      offWindowFocus = registerWindowFocusAccountRefresh(
        (handler) => Events.On("common:WindowFocus", handler),
        loadAccounts,
      );
    }

    fileDropInterceptor.set((paths: string[]) => fileDropIntercept(paths, createFileDropCtx()));
  });

  onDestroy(() => {
    accountLoadGuard.invalidate();
    for (const t of refreshTimers) clearTimeout(t);
    refreshTimers = [];
    clearTagExpiryTimer();
    if (overlayQueryDebounceTimer) clearTimeout(overlayQueryDebounceTimer);
    selectedAccountStore.set({ platformKey: "", uniqueId: "", displayName: "", accountLogin: "" });
    platformLiveSessionId.set({ platformKey: "", uniqueId: "" });
    platformAction.set(null);
    offPlatformAction?.();
    offSort?.();
    offAccountsRefresh?.();
    offUpdateEvent?.();
    for (const off of offExtraUpdateEvents.splice(0)) off();
    offGameStatsUpdated?.();
    offWindowFocus?.();
    accountProfileImageDropActive.set(false);
    fileDropInterceptor.set(null);
    platformAccountsRefresh.set({ seq: 0, platformKey: "" });
    platformExeIconUrl.set("");
    actionBarStatus.set("");
    adapter.onCleanup?.();
  });
</script>

<div class="main-content platform-accounts-root">
  {#if name}
    <div class="platformTableHost">
      <SearchOverlay
        open={so.open}
        syncNonce={so.nonce}
        initialQuery={so.initialQuery}
        bind:query={overlayQuery}
        placeholder={commandMode ? $t("Command_SearchPlaceholder") : $t("Context_Search")}
        primaryRows={searchPrimary}
        categoryRows={[]}
        categoryHint=""
        gameRows={commandMode ? [] : (adapter.gameSearchRows?.(debouncedOverlayQuery) ?? [])}
        gameHint={commandMode ? "" : (adapter.gameSearchHint ?? "")}
        on:close={() => closeSearchOverlay()}
        on:pick={(e) => void onSearchPick(e)}
      />
      <div class="platformTable">
      {#if loadError}
        <p class="platform-accounts-hint">{loadError}</p>
      {/if}
      <!-- svelte-ignore a11y-click-events-have-key-events -->
      <!-- svelte-ignore a11y-no-static-element-interactions -->
      <div
        class="steam-acclist"
        bind:this={acclistEl}
        on:click={onAccountsAreaClick}
        on:dragleave={onAccListDragLeave}
        use:ctxMenuAction={{ items: backgroundMenu, paginate: false }}
      >
        {#if hasActiveTags}
          <TagFilterBar label={tagFilterBarLabel} onClick={onTagFilterBarClick} disabled={tagDefs.length === 0} />
        {/if}
        {#if accountsLoading && displayIds.length === 0 && skeletonCount > 0}
          <AccountListSkeleton count={skeletonCount} />
        {:else}
        <ReorderPointerGrid
          items={displayIds}
          reorderDisabled={reorderDisabled}
          listClass="acc_list"
          itemClass="acc_list_item acc_list_item--drag"
          placeholderClass="acc_list_item placeHolderAcc"
          ghostClass="acc_list_item acc_list_item--ghost"
          ariaLabel="Accounts"
          itemAriaLabel={accountGridLabel}
          activeItem={selectedId || undefined}
          selectOnArrow={true}
          on:reorder={(e) => { accountIds = e.detail.items; adapter.saveOrder(e.detail.items).catch(() => {}); }}
          on:itemclick={onItemClick}
        >
          <svelte:fragment slot="item" let:rowId>
            {@const rid = slotKey(rowId)}
            {@const acc = accountMap.get(rid)}
            {@const radioId = `acc-${adapter.platformKey}-${rid}`}
            {@const labelId = `${radioId}-label`}
            {@const descId = `${radioId}-desc`}
            {#if acc}
              {@const a11yDescription = accountA11yDescription(acc, rid)}
              {@const nameStatus = adapter.nameStatus?.(acc) ?? null}
              {#key `${rid}-${avatarEpoch[rid] ?? 0}-${rowVersions[rid] ?? 0}`}
              <div class="acc_list_item_inner">
                <input
                  type="radio"
                  class="acc"
                  id={radioId}
                  name={`${adapter.platformKey}-accounts`}
                  value={rid}
                  tabindex="-1"
                  bind:group={selectedId}
                  aria-labelledby={labelId}
                  aria-describedby={a11yDescription ? descId : undefined}
                  on:change={touchStatus}
                />
                <label
                  for={radioId}
                  class="acc"
                  class:currentAcc={adapter.currentSession(acc)}
                  class:acc--broken={adapter.savedDataBroken?.(acc) === true}
                  class:acc--profile-drop-target={$accountProfileImageDropActive && !imagePick.open}
                  class:acc--drop-target={fileDragHoverRowId === rid}
                  on:dragover={(e) => onAccDragOver(e, rid)}
                  on:dragleave={(e) => onAccDragLeave(e, rid)}
                  use:ctxMenuAction={{
                    items: ctxMenu(rid),
                    beforeOpen: () => { selectedId = rid; touchStatus(); },
                  }}
                  on:dblclick|preventDefault={() => {
                    if (isActionBusy) return;
                    if (adapter.savedDataBroken?.(acc)) return;
                    selectedId = rid;
                    touchStatus();
                    void swapToLogin();
                  }}
                >
                  <AccountLiveSessionIndicator
                    active={adapter.currentSession(acc)}
                    tooltipText={$t("Tooltip_CurrentAccount")}
                    boundary={acclistEl}
                  />
                  {#if adapter.savedDataBroken?.(acc)}
                    <span class="acc_broken_badge">{$t("Security_AccountDataBroken")}</span>
                  {/if}
                  {#if $accountProfileImageDropActive && !imagePick.open}
                    <div class="acc_profile_drop_overlay" class:acc_profile_drop_overlay--hover={fileDragHoverRowId === rid} aria-hidden="true">
                      <div class="acc_profile_drop_overlay__center">
                        <div class="acc_profile_drop_overlay__icon" aria-hidden="true">
                          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="M5 20h14v-2H5v2zM19 9h-4V3H9v6H5l7 7 7-7z"/></svg>
                        </div>
                        <span class="acc_profile_drop_overlay__label">{$t("Drop_SetAccountIcon")}</span>
                      </div>
                    </div>
                  {/if}

                  <slot name="account-avatar" {acc} epoch={avatarEpoch[rid] ?? 0} fallback={adapter.profileFallback}>
                    <img
                      src={heldAvatarSrc(heldAvatarKey("list", rid), accountAvatarSrc({
                        streamer: $streamerMode,
                        salt: $avatarSalt,
                        platformKey: adapter.platformKey,
                        accountKey: adapter.accountLogin(acc) || rid,
                        imageUrl: adapter.imageUrl(acc),
                        pending: adapter.imagePending(acc),
                        epoch: avatarEpoch[rid] ?? 0,
                        offline: $offlineMode,
                        fallback: adapter.profileFallback,
                      }), $avatarSwapped)}
                      alt="" draggable="false"
                    />
                  </slot>

                  <slot name="account-before-name" {acc} />

                  <h6
                    id={labelId}
                    class="displayName"
                    class:acc_name--vac={nameStatus?.kind === "vac"}
                    class:acc_name--limited={nameStatus?.kind === "limited"}
                    title={nameStatus?.label}
                  >{$censoredName(adapter.name(acc))}</h6>

                  {#if a11yDescription}
                    <span id={descId} class="sr-only">{a11yDescription}</span>
                  {/if}

                  <!-- Sits directly under the community name. Placed after the
                       sr-only span so the label/description pair stays adjacent
                       to the heading it belongs to. -->
                  <slot name="account-after-name" {acc} />

                  <AccountTagBubbles tags={adapter.tags(acc) ?? []} />

                  {#if adapter.shouldShowNote(acc)}
                    <p class="acc_note">{adapter.note(acc)}</p>
                  {/if}

                  {#if gameStatsByAccount[rid] && Object.keys(gameStatsByAccount[rid]).length > 0}
                    <div class="acc_inline_gamestats" aria-label={$t("Context_ManageGameStats")}>
                      <span class="acc_inline_gamestats_metrics">
                        {#each Object.values(gameStatsByAccount[rid]) as metrics}
                          {#each Object.values(metrics) as dto}
                            {@const statTip = resolveGameStatTooltip(dto.tooltip, $t)}
                            <span
                              class="acc_inline_gamestats_metric"
                              use:tooltipAction={statTip ? { text: statTip, boundary: acclistEl } : undefined}
                            >
                              {#if dto.indicatorMarkup}
                                <span class="acc_inline_gamestats_ind">{@html sanitizeHtml(dto.indicatorMarkup, "gameStats")}</span>
                              {/if}
                              <span class="acc_inline_gamestats_val">{@html sanitizeHtml(dto.statValue, "gameStats")}</span>
                            </span>
                          {/each}
                        {/each}
                      </span>
                    </div>
                  {/if}

                  <slot name="account-after-stats" {acc} />

                  {#if adapter.shouldShowLastUsed(acc)}
                    <p class="acc_lastused">{formatLastLoginForLocale(adapter.lastUsed(acc), $locale)}</p>
                  {/if}

                  <slot name="account-footer" {acc} />
                </label>
              </div>
              {/key}
            {/if}
          </svelte:fragment>
        </ReorderPointerGrid>
        {/if}
      </div>
    </div>
    </div>
    <AccountImagePickOverlay
      bind:open={imagePick.open}
      accountDisplayName={imagePick.displayName}
      showRemoveButton={imagePick.manual}
      onClose={closeImagePick}
      onApplyPath={applyImageFromOverlay}
      onRemoveManual={removeImageFromOverlay}
    />
  {/if}
</div>
<svelte:window on:keydown={onWindowKeyDown} />
