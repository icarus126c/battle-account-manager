<script lang="ts">
  import type { MenuItemDef } from "../stores/contextMenu";
  import ContextMenuProgress from "./ContextMenuProgress.svelte";
  import { onDestroy, tick } from "svelte";
  import { get } from "svelte/store";
  import { closeContextMenu, submenuOpenPath, submenuExpandEnabled } from "../stores/contextMenu";
  import {
    balancedSubmenuPageRanges,
    scaleFromComputedTransform,
    toLayoutPx,
    type SubmenuPageRange,
  } from "../lib/contextMenuLayout";
  const CTX_MENU_DEBUG = false;
  function ctxMenuLog(...args: unknown[]): void {
    if (CTX_MENU_DEBUG) console.log("[ctx-menu]", ...args);
  }
  import { t } from "../stores/i18n";

  const SEARCH_THRESHOLD = 5;

  export let items: MenuItemDef[] = [];
  export let layoutEpoch = 0;
  /** submenu depth for CSS class */
  export let depth = 1;
  /** Path of indices from root down to this list's parent (empty at root column). */
  export let pathPrefix: number[] = [];
  /** False draws every flyout row at once; see ContextMenuOptions.paginate. */
  export let paginate = true;

  /** Search row and paging are flyout-column concerns — the root list has neither. */
  $: isFlyoutColumn = pathPrefix.length > 0;
  $: paginateThisColumn = isFlyoutColumn && paginate;

  let searchQuery = "";
  let currentPage = 0;
  let columnSentinel: HTMLLIElement | null = null;
  let pageRanges: SubmenuPageRange[] = [];
  let measuring = false;
  let measuredSignature = "";
  let measurementRun = 0;



  function norm(s: string): string {
    return s.toLowerCase();
  }

  /** Word separators for acronym-style label search; any run of them starts a new word. */
  const LABEL_WORD_SPLIT_RE = /[\s\u00A0\-_–—:;,.|/\\\u2026]+/u;

  function splitLabelWords(label: string): string[] {
    return label
      .trim()
      .split(LABEL_WORD_SPLIT_RE)
      .map((w) => w.trim())
      .filter((w) => w.length > 0);
  }

  function firstGrapheme(word: string): string {
    if (!word) {
      return "";
    }
    try {
      const Seg = (Intl as typeof Intl & { Segmenter?: typeof Intl.Segmenter }).Segmenter;
      if (Seg) {
        const seg = new Seg(undefined, { granularity: "grapheme" });
        for (const { segment } of seg.segment(word)) {
          return segment;
        }
      }
    } catch {
      /* Segmenter unsupported or invalid locale */
    }
    return [...word][0] ?? "";
  }

  /** Concatenation of first grapheme per word, e.g. "Counter-Strike: 2" → "CS2". */
  function labelAcronymHaystack(label: string): string {
    return splitLabelWords(label).map(firstGrapheme).join("");
  }

  $: hasSearchMarker = items[0]?.type === "search";
  $: tail = hasSearchMarker ? items.slice(1) : items;
  $: alwaysShowSearchFlyout =
    hasSearchMarker && !!(items[0] as { alwaysShowSearch?: boolean } | undefined)?.alwaysShowSearch;
  /** Search row only in flyout columns; `alwaysShowSearch` forces it for small lists. */
  $: showSearchRow =
    isFlyoutColumn && (tail.length > SEARCH_THRESHOLD || alwaysShowSearchFlyout);
  $: q = norm(searchQuery.trim());
  $: trimmedSearchQuery = searchQuery.trim();
  $: searchItem = items[0];
  $: searchEnterCb =
    searchItem?.type === "search"
      ? (searchItem as { onSearchEnter?: (q: string) => void }).onSearchEnter
      : undefined;
  $: searchCanCreateCb =
    searchItem?.type === "search"
      ? (searchItem as { onSearchCanCreate?: (q: string) => boolean }).onSearchCanCreate
      : undefined;
  $: searchCreateCb =
    searchItem?.type === "search"
      ? (searchItem as { onSearchCreate?: (q: string) => void }).onSearchCreate
      : undefined;
  $: showCreateRow =
    showSearchRow &&
    trimmedSearchQuery !== "" &&
    !!searchEnterCb &&
    (searchCanCreateCb ? searchCanCreateCb(trimmedSearchQuery) : true);

  /** Stable row visibility for search (indices must match pathPrefix). */
  function rowMatchesSearch(it: MenuItemDef): boolean {
    if (!showSearchRow || q === "") {
      return true;
    }
    if (it.type === "separator") {
      return false;
    }
    if (!it.label) {
      return false;
    }
    const lab = norm(it.label);
    if (lab.includes(q)) {
      return true;
    }
    const ac = norm(labelAcronymHaystack(it.label));
    return ac.length > 0 && ac.includes(q);
  }

  type TailEntry = { item: MenuItemDef; idx: number };

  /** Rows under this column after search filter (pagination slices this list). */
  $: filteredTailEntries = (() => {
    void showSearchRow;
    void q;
    const out: TailEntry[] = [];
    for (let idx = 0; idx < tail.length; idx++) {
      const item = tail[idx]!;
      if (!rowMatchesSearch(item)) {
        continue;
      }
      out.push({ item, idx });
    }
    return out;
  })();

  function pathIsOpen(path: number[], openPath: number[]): boolean {
    return path.length > 0 &&
      path.length <= openPath.length &&
      path.every((value, index) => openPath[index] === value);
  }

  $: columnVisible = paginateThisColumn && pathIsOpen(pathPrefix, $submenuOpenPath);
  $: measurementSignature = [
    layoutEpoch,
    showSearchRow ? 1 : 0,
    showCreateRow ? 1 : 0,
    trimmedSearchQuery,
    ...filteredTailEntries.map(({ item, idx }) => `${idx}:${item.type}:${item.label ?? ""}`),
  ].join("|");

  async function measureColumn(signature: string): Promise<void> {
    const column = columnSentinel?.parentElement;
    if (!(column instanceof HTMLUListElement)) {
      measuredSignature = "";
      return;
    }

    const run = ++measurementRun;
    column.classList.add("ctx-submenu-measuring");
    measuring = true;
    await tick();

    if (run !== measurementRun) {
      return;
    }
    if (signature !== measuredSignature || !pathIsOpen(pathPrefix, get(submenuOpenPath))) {
      column.classList.remove("ctx-submenu-measuring");
      measuring = false;
      measuredSignature = "";
      return;
    }

    const root = column.closest(".ctx-menu-root");
    if (!(root instanceof HTMLElement)) {
      column.classList.remove("ctx-submenu-measuring");
      measuring = false;
      measuredSignature = "";
      return;
    }

    // Every rect below is read through the root menu's scale-in transform when a submenu opens in
    // the same frame the menu appears; the page split is scale-invariant, the written height is not.
    const scale = scaleFromComputedTransform(getComputedStyle(root).transform);
    const rows = Array.from(column.children).filter(
      (child): child is HTMLElement => child instanceof HTMLElement,
    );
    const itemRows = rows.filter((row) => row.hasAttribute("data-page-measure-row"));
    const searchRow = rows.find((row) => row.classList.contains("contextSearch"));
    const createRow = rows.find((row) => row.classList.contains("ctx-create-li"));
    const paginationRow = rows.find((row) => row.classList.contains("ctx-pagination-li"));
    const fixedHeightWithoutPagination = [searchRow, createRow]
      .reduce((height, row) => height + (row?.getBoundingClientRect().height ?? 0), 0);
    const paginationHeight = paginationRow?.getBoundingClientRect().height ?? 0;
    const fixedHeightWithPagination = fixedHeightWithoutPagination + paginationHeight;
    const rootHeight = root.getBoundingClientRect().height;
    const rowHeights = itemRows.map((row) => row.getBoundingClientRect().height);
    const nextRanges = balancedSubmenuPageRanges(
      rowHeights,
      rootHeight - fixedHeightWithoutPagination,
      rootHeight - fixedHeightWithPagination,
    );
    const usesPagination = nextRanges.length > 1;
    const tallestPageHeight = nextRanges.reduce((tallest, range) => {
      const height = rowHeights
        .slice(range.start, range.end)
        .reduce((total, rowHeight) => total + rowHeight, 0);
      return Math.max(tallest, height);
    }, 0);
    const plannedHeight = Math.min(
      rootHeight,
      tallestPageHeight + (usesPagination ? fixedHeightWithPagination : fixedHeightWithoutPagination),
    );

    column.style.setProperty(
      "--ctx-submenu-planned-height",
      `${toLayoutPx(plannedHeight, scale)}px`,
    );
    pageRanges = nextRanges;
    currentPage = Math.min(currentPage, Math.max(0, nextRanges.length - 1));
    measuring = false;
    await tick();

    if (run === measurementRun) {
      // Drop the measuring class first: the listener fits the flyout synchronously, and while the
      // class is on, the column is still `height: auto` rather than the box just planned for it.
      column.classList.remove("ctx-submenu-measuring");
      column.dispatchEvent(new CustomEvent("ctxsubmenuplanned", { bubbles: true }));
    }
  }

  $: if (columnVisible && measurementSignature !== measuredSignature) {
    measuredSignature = measurementSignature;
    void measureColumn(measurementSignature);
  }

  $: pageCount = Math.max(1, pageRanges.length);
  $: showPagination = paginateThisColumn && !measuring && pageCount > 1;
  $: activeRange = pageRanges[currentPage];
  $: pagedTailEntries = !paginateThisColumn || measuring
    ? filteredTailEntries
    : activeRange
      ? filteredTailEntries.slice(activeRange.start, activeRange.end)
      : filteredTailEntries.slice(0, SEARCH_THRESHOLD);
  $: renderPagination = paginateThisColumn &&
    ((measuring && filteredTailEntries.length > 1) || showPagination);

  $: if (currentPage >= pageCount) {
    currentPage = Math.max(0, pageCount - 1);
  }

  function onSearchInput(): void {
    currentPage = 0;
  }

  function changePage(delta: number): void {
    submenuOpenPath.set([...pathPrefix]);
    currentPage = Math.max(0, Math.min(pageCount - 1, currentPage + delta));
  }

  function submenuClass(d: number): string {
    return d <= 1 ? "submenu submenu1" : "submenu submenu2";
  }

  function pathsEqual(a: number[], b: number[]): boolean {
    if (a.length !== b.length) {
      return false;
    }
    return a.every((v, i) => v === b[i]);
  }

  function stop(ev: Event): void {
    ev.stopPropagation();
  }

  function run(item: MenuItemDef): void {
    if (item.disabled) {
      return;
    }
    item.action?.();
    closeContextMenu();
  }

  /**
   * Which row index under this list is expanded — must be a `$:` reactive block so
   * `class:submenu-expanded` updates when `submenuOpenPath` changes (store reads inside plain
   * helper functions called from markup are not always subscribed in Svelte).
   */
  $: expandedIdxAtLevel = (() => {
    const p = $submenuOpenPath;
    if (p.length <= pathPrefix.length) {
      return undefined;
    }
    for (let i = 0; i < pathPrefix.length; i++) {
      if (p[i] !== pathPrefix[i]) {
        return undefined;
      }
    }
    return p[pathPrefix.length];
  })();

  /**
   * Expand via hover / movement. Requires layout to have finished (`submenuExpandEnabled`).
   * Supports both Pointer and Mouse events — WebView2 sometimes delivers `mousemove`/`mouseenter`
   * without meaningful `pointermove`.
   */
  function expandBranch(idx: number, source: string): void {
    if (!get(submenuExpandEnabled)) {
      return;
    }
    const next = [...pathPrefix, idx];
    submenuOpenPath.update((cur) => {
      if (pathsEqual(cur, next)) {
        return cur;
      }
      ctxMenuLog("expandBranch", {
        source,
        depth,
        idx,
        pathPrefix,
        newPath: next,
      });
      return next;
    });
  }

  /**
   * Collapse deeper paths when moving onto a leaf at this column.
   * If `elementFromPoint` is not inside this `li`, a sibling row was stacked above the flyout — ignore.
   */
  function onLeafPointerEnter(ev: PointerEvent): void {
    const li = ev.currentTarget as HTMLElement;
    const hit = document.elementFromPoint(ev.clientX, ev.clientY);
    if (!hit || !li.contains(hit)) {
      ctxMenuLog("leaf enter ignored (top hit not inside this row)", {
        hitNode: hit instanceof Node ? hit.nodeName : hit,
      });
      return;
    }
    const next = [...pathPrefix];
    submenuOpenPath.update((cur) => {
      if (pathsEqual(cur, next)) {
        return cur;
      }
      ctxMenuLog("leaf enter → trim path", next);
      return next;
    });
  }

  /** Allow navigation keys to bubble to `.ctx-menu-root`; stop others so they don't hit the page. */
  function onSearchKeydown(ev: KeyboardEvent): void {
    const k = ev.key;
    if (k === "Enter") {
      if (searchEnterCb && trimmedSearchQuery !== "") {
        ev.preventDefault();
        ev.stopPropagation();
        searchEnterCb(trimmedSearchQuery);
        closeContextMenu();
        return;
      }
    }
    if (
      k === "ArrowDown" ||
      k === "ArrowUp" ||
      k === "Home" ||
      k === "End" ||
      k === "Escape"
    ) {
      return;
    }
    ev.stopPropagation();
  }

  function onCreateClick(): void {
    if (trimmedSearchQuery === "" || !showCreateRow) {
      return;
    }
    if (searchCreateCb) {
      searchCreateCb(trimmedSearchQuery);
    } else if (searchEnterCb) {
      searchEnterCb(trimmedSearchQuery);
    } else {
      return;
    }
    closeContextMenu();
  }

  function itemDomId(idx: number): string {
    return `ctx-menu-item-${[...pathPrefix, idx].join("-")}`;
  }

  function submenuDomId(idx: number): string {
    return `ctx-menu-submenu-${[...pathPrefix, idx].join("-")}`;
  }

  onDestroy(() => {
    measurementRun++;
    columnSentinel?.parentElement?.classList.remove("ctx-submenu-measuring");
  });

</script>

{#if paginateThisColumn}
  <li
    bind:this={columnSentinel}
    class="ctx-column-sentinel"
    role="none"
  ></li>
{/if}

{#if showSearchRow}
  <li class="contextSearch" role="none" on:pointerdown={stop}>
    <input
      type="search"
      class="ctx-menu__search"
      aria-label={hasSearchMarker ? items[0]?.label || $t("Context_Search") : $t("Context_Search")}
      placeholder={hasSearchMarker ? items[0]?.label || $t("Context_Search") : $t("Context_Search")}
      bind:value={searchQuery}
      on:input={onSearchInput}
      on:pointerdown={stop}
      on:keydown={onSearchKeydown}
    />
  </li>
{/if}

{#if showCreateRow}
  <li class="ctx-create-li" role="none" on:pointerdown={stop}>
    <button type="button" class="ctx-menu__btn" role="menuitem" on:click={onCreateClick}
      >{$t("Context_CreateTag")} {trimmedSearchQuery}</button
    >
  </li>
{/if}

{#each pagedTailEntries as { item, idx } (idx)}
  {#if item.type === "separator"}
    <li class="ctx-sep" role="separator" data-page-measure-row><hr /></li>
  {:else if item.children?.length}
    <li
      class="hasSubmenu"
      class:hasSubmenu--parent-action={!!item.action}
      class:submenu-expanded={expandedIdxAtLevel === idx}
      role="none"
      data-page-measure-row
      data-submenu-path={JSON.stringify([...pathPrefix, idx])}
      on:pointerenter={() => expandBranch(idx, "pointerenter")}
      on:mouseenter={() => expandBranch(idx, "mouseenter")}
    >
      {#if item.action}
        <button
          id={itemDomId(idx)}
          type="button"
          class="ctx-menu__btn ctx-menu__parent-action"
          role="menuitem"
          tabindex="-1"
          aria-haspopup="true"
          aria-expanded={expandedIdxAtLevel === idx}
          aria-controls={submenuDomId(idx)}
          disabled={item.disabled}
          aria-disabled={item.disabled ? "true" : undefined}
          on:pointermove={() => expandBranch(idx, "pointermove")}
          on:mousemove={() => expandBranch(idx, "mousemove")}
          on:click={() => run(item)}>{item.label}</button
        >
      {:else}
        <button
          id={itemDomId(idx)}
          type="button"
          role="menuitem"
          tabindex="-1"
          aria-haspopup="true"
          aria-expanded={expandedIdxAtLevel === idx}
          aria-controls={submenuDomId(idx)}
          class="ctx-menu__label"
          on:pointermove={() => expandBranch(idx, "pointermove")}
          on:mousemove={() => expandBranch(idx, "mousemove")}
          on:click={() => expandBranch(idx, "click")}
        >
          {item.label}
        </button>
      {/if}
      <ul
        id={submenuDomId(idx)}
        class={submenuClass(depth)}
        role="menu"
        aria-labelledby={itemDomId(idx)}
      >
        <svelte:self
          items={item.children ?? []}
          {layoutEpoch}
          {paginate}
          depth={depth + 1}
          pathPrefix={[...pathPrefix, idx]}
        />
      </ul>
    </li>
  {:else}
    <li role="none" data-page-measure-row on:pointerenter={(e) => onLeafPointerEnter(e)}>
      <button
        id={itemDomId(idx)}
        type="button"
        class="ctx-menu__btn"
        role="menuitem"
        class:ctx-menu__btn--disabled={item.disabled}
        disabled={item.disabled}
        aria-disabled={item.disabled ? "true" : undefined}
        tabindex={item.disabled ? -1 : undefined}
        on:click={() => run(item)}>{item.label}</button>
      {#if item.progress}
        <ContextMenuProgress progress={item.progress} />
      {/if}
    </li>
  {/if}
{/each}

{#if renderPagination}
  <li
    class="ctx-pagination-li"
    role="none"
    data-total-items={filteredTailEntries.length}
    on:pointerdown={stop}
  >
    <div class="paginationContainer">
      <div class="pagination">
      {#if currentPage >= 1}
        <button
          type="button"
          class="paginationButton paginationButton--prev"
          aria-label={$t("Aria_PreviousPage")}
          on:pointerdown={stop}
          on:click={() => changePage(-1)}
        >
          <i aria-hidden="true">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512" width="12" height="12">
              <path
                fill="currentColor"
                d="M34.52 239.03L228.87 44.69c9.37-9.37 24.57-9.37 33.94 0l22.67 22.67c9.36 9.36 9.37 24.52.04 33.9L131.49 256l154.02 154.75c9.34 9.38 9.32 24.54-.04 33.9l-22.67 22.67c-9.37 9.37-24.57 9.37-33.94 0L34.52 272.97c-9.37-9.37-9.37-24.57 0-33.94z"
              />
            </svg>
          </i>
        </button>
      {:else}
        <button
          type="button"
          class="paginationButton paginationButton--prev"
          style="visibility: hidden"
          aria-hidden="true"
          tabindex="-1"
          disabled
        >
          <i aria-hidden="true">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512" width="12" height="12">
              <path
                fill="currentColor"
                d="M34.52 239.03L228.87 44.69c9.37-9.37 24.57-9.37 33.94 0l22.67 22.67c9.36 9.36 9.37 24.52.04 33.9L131.49 256l154.02 154.75c9.34 9.38 9.32 24.54-.04 33.9l-22.67 22.67c-9.37 9.37-24.57 9.37-33.94 0L34.52 272.97c-9.37-9.37-9.37-24.57 0-33.94z"
              />
            </svg>
          </i>
        </button>
      {/if}
      <span>{currentPage + 1} / {pageCount}</span>
      {#if currentPage < pageCount - 1}
        <button
          type="button"
          class="paginationButton paginationButton--next"
          aria-label={$t("Aria_NextPage")}
          on:pointerdown={stop}
          on:click={() => changePage(1)}
        >
          <i aria-hidden="true">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 320 512"
              width="12"
              height="12"
              style="transform: scaleX(-1)"
            >
              <path
                fill="currentColor"
                d="M34.52 239.03L228.87 44.69c9.37-9.37 24.57-9.37 33.94 0l22.67 22.67c9.36 9.36 9.37 24.52.04 33.9L131.49 256l154.02 154.75c9.34 9.38 9.32 24.54-.04 33.9l-22.67 22.67c-9.37 9.37-24.57 9.37-33.94 0L34.52 272.97c-9.37-9.37-9.37-24.57 0-33.94z"
              />
            </svg>
          </i>
        </button>
      {:else}
        <button
          type="button"
          class="paginationButton paginationButton--next"
          style="visibility: hidden"
          aria-hidden="true"
          tabindex="-1"
          disabled
        >
          <i aria-hidden="true">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 320 512"
              width="12"
              height="12"
              style="transform: scaleX(-1)"
            >
              <path
                fill="currentColor"
                d="M34.52 239.03L228.87 44.69c9.37-9.37 24.57-9.37 33.94 0l22.67 22.67c9.36 9.36 9.37 24.52.04 33.9L131.49 256l154.02 154.75c9.34 9.38 9.32 24.54-.04 33.9l-22.67 22.67c-9.37 9.37-24.57 9.37-33.94 0L34.52 272.97c-9.37-9.37-9.37-24.57 0-33.94z"
              />
            </svg>
          </i>
        </button>
      {/if}
      </div>
    </div>
  </li>
{/if}

<style lang="scss">
  .row-hidden {
    display: none !important;
  }
</style>
