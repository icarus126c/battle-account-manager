import { writable, type Readable } from "svelte/store";
const CTX_MENU_DEBUG = false;
function ctxMenuLog(...args: unknown[]): void {
  if (CTX_MENU_DEBUG) console.log("[ctx-menu]", ...args);
}

export type MenuItemDef = {
  /** Ignored when type is search/separator */
  label?: string;
  type?: "item" | "search" | "separator";
  /** Leaf click, or with `children` a parent row click (see ContextMenuNest). */
  action?: () => void;
  children?: MenuItemDef[];
  /** When true, the row is visible but not clickable (no action, menu stays open on click). */
  disabled?: boolean;
  /**
   * On a `type: "search"` row in a submenu: show the filter input even when the sibling list has
   * five or fewer items (default submenu search only appears above that threshold).
   */
  alwaysShowSearch?: boolean;
  /** On `type: "search"`: invoked when Enter is pressed with a non-empty trimmed query. */
  onSearchEnter?: (query: string) => void;
  /** On `type: "search"`: when true, show a synthetic `Create: <query>` row. */
  onSearchCanCreate?: (query: string) => boolean;
  /** On `type: "search"`: action for clicking synthetic `Create: <query>` row. */
  onSearchCreate?: (query: string) => void;
  /**
   * Leaf rows only: a fraction counting 1 → 0, drawn as a shrinking underline that
   * turns yellow then red as it runs out. For rows whose action is only worth
   * clicking while something is still valid.
   */
  progress?: Readable<number>;
};

export type ContextMenuState =
  | null
  | {
      x: number;
      y: number;
      items: MenuItemDef[];
      anchorRect?: ContextMenuAnchorRect;
      paginate?: boolean;
    };

export type ContextMenuOptions = {
  /**
   * Flyout columns page themselves against the root column's height, so a short root menu
   * splits a handful of rows across a page each. Set false on menus whose submenus are
   * always short enough to draw in full.
   */
  paginate?: boolean;
};

export type ContextMenuAnchorRect = {
  left: number;
  right: number;
  top: number;
  bottom: number;
  width: number;
  height: number;
};

export const contextMenu = writable<ContextMenuState>(null);

/** Indices from root — which branches are expanded (e.g. [4, 0] = root item 4, then child 0). */
export const submenuOpenPath = writable<number[]>([]);

/**
 * False until the menu has painted (tick + rAF). Blocks pointerenter in the same frame as mount
 * so a submenu doesn’t pop open when the menu first appears under the cursor.
 */
export const submenuExpandEnabled = writable(false);

export function openContextMenu(
  x: number,
  y: number,
  items: MenuItemDef[],
  options: ContextMenuOptions = {},
): void {
  ctxMenuLog("openContextMenu", { x, y, itemCount: items.length });
  submenuOpenPath.set([]);
  submenuExpandEnabled.set(false);
  contextMenu.set({ x, y, items, paginate: options.paginate });
}

export function openContextMenuAtRect(
  rect: ContextMenuAnchorRect,
  items: MenuItemDef[],
  options: ContextMenuOptions = {},
): void {
  ctxMenuLog("openContextMenuAtRect", { rect, itemCount: items.length });
  submenuOpenPath.set([]);
  submenuExpandEnabled.set(false);
  contextMenu.set({
    x: rect.left,
    y: rect.bottom,
    items,
    anchorRect: { ...rect },
    paginate: options.paginate,
  });
}

export function closeContextMenu(): void {
  ctxMenuLog("closeContextMenu");
  submenuOpenPath.set([]);
  submenuExpandEnabled.set(false);
  contextMenu.set(null);
}
