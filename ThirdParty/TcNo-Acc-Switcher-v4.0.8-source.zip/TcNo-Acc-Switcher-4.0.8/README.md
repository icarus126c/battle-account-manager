
<p align="center">
  <a href="https://tcno.co/">
    <img src="/other/img/Banner.png"></a>
</p>
<p align="center">
  <img alt="GitHub All Releases" src="https://img.shields.io/github/downloads/TCNOco/TcNo-Acc-Switcher/total?logo=GitHub&style=flat-square">
  <a href="https://tcno.co/">
    <img alt="Website" src="/other/img/web.svg" height=20></a>
  <a href="https://s.tcno.co/AccSwitcherDiscord">
    <img alt="Discord server" src="https://img.shields.io/discord/217649733915770880?label=Discord&logo=discord&style=flat-square"></a>
  <a href="https://twitter.com/TCNOco">
    <img alt="Twitter" src="https://img.shields.io/twitter/follow/TCNOco?label=Follow%20%40TCNOCo&logo=Twitter&style=flat-square"></a>
  <img alt="GitHub last commit" src="https://img.shields.io/github/last-commit/TCNOco/TcNo-Acc-Switcher?logo=GitHub&style=flat-square">
  <img alt="GitHub repo size" src="https://img.shields.io/github/repo-size/TCNOco/TcNo-Acc-Switcher?logo=GitHub&style=flat-square">
																     <a title="Crowdin" target="_blank" href="https://crowdin.com/project/tcno-account-switcher"><img src="https://img.shields.io/badge/Seeking-localisers-blue.svg?style=flat-square"></a>
</p>
<p align="center">
  <a href="https://patreon.com/TroubleChute">
    <img alt="Patreon" src="https://img.shields.io/badge/Patreon-F96854?style=for-the-badge&logo=patreon&logoColor=white"></a>
  <a href="https://ko-fi.com/art?=redirect">
    <img alt="Ko-Fi" src="https://img.shields.io/badge/Ko--fi-F16061?style=for-the-badge&logo=ko-fi&logoColor=white"></a>
</p> 

<p align="center"><a target="_blank" href="https://github.com/TCNOco/TcNo-Acc-Switcher/releases/latest">
  <img alt="Download latest" src="/other/img/DownloadLatestNEW.png" height=70"></a>
  <a target="_blank" href="https://github.com/TCNOco/TcNo-Acc-Switcher/wiki">
  <img alt="More info" src="/other/img/WikiButton.png" height=70"></a>
</p>
<p align="center"><a target="_blank" href="https://github.com/TCNOco/TcNo-Acc-Switcher-Themes">
  <img alt="Themes" src="/other/img/Themes.png" height=70"></a>
  <a target="_blank" href="https://github.com/TCNOco/TcNo-Acc-Switcher/wiki/Frequently-Asked-Questions">
  <img alt="Themes" src="/other/img/FAQButton.png" height=70"></a>
</p>
  
**A Superfast open-source account switcher for Steam, Battle.net, Epic Games, Origin, Riot Games, Ubisoft, and more**.
							     
**Saves NO passwords** or any user information (besides what you choose to enter). Most switchers, including Steam work purely off changing a file and a few registry keys.
*Wastes no time closing, switching and restarting Steam and other platforms.*<br />
**NOTE:** Not created for cheating purposes. All it does is change accounts. Use it as you see fit, accepting responsibility.

The optional native Steam Guard feature stores encrypted authenticator secrets and uses Steam's mobile endpoints. Read the [Steam Guard backup and security guide](docs/steam-guard.md) before enabling it.

# How does it work?
Simple. It swaps out files and registry values that point to your last logged in account while the program is closed. Think of it as freezing a platform like Steam in time, and replacing the "account block" with a previously frozen "account block", then unfreezing it. To Steam and your Steam account, it "looks" like you pulled your plug out and put it back in a week or so later, meanwhile you were playing on other accounts. Ordinary account switching still does not require a password or two-factor code; the optional Steam Guard feature is a separate, explicit workflow.

You can see (and edit) how account switching works by checking [Platforms.json](https://github.com/TCNOco/TcNo-Acc-Switcher/blob/go/Platforms.json).

This software values your privacy. Please see the [Privacy Policy](https://github.com/TCNOco/TcNo-Acc-Switcher/blob/master/PRIVACY.md).

## HELP  WANTED

This project is a massive time sink for something completely open-source and free. Consider supporting development on [Patreon](https://www.patreon.com/TroubleChute), [Ko-Fi](https://ko-fi.com/tcnoco) or as a YouTube Member on [TroubleChute](https://youtube.com/TroubleChute).

- Speak another language? [Help Translate this on Crowdin](https://crowdin.com/project/tcno-account-switcher).
- Code? Any and all help is appreciated.
- Help by [adding platforms](https://github.com/TCNOco/TcNo-Acc-Switcher/wiki/Help-code-a-platform) - No coding required!

Please report any and all bugs, as well as steps to recreate them into the Issues section, or the `#bug-report` channel under `TCNO ACCOUNT SWITCHER` section on the [Community Discord](https://s.tcno.co/AccSwitcherDiscord).

<h2><img alt="Youtube" src="/other/img/youtube.svg" height=18"> List of all platforms (Click for video guides):</h2>

Albion Online, **[Battle.net](https://youtu.be/cvbo_VY05bo?list=PLsSFD61FiOVmAwChPSrIFkjDLoLsyqcU6)**, **Discord (+ PTB & Canary)**, **[Epic Games](https://www.youtube.com/watch?v=gd9oS6wiKmU&list=PLsSFD61FiOVmAwChPSrIFkjDLoLsyqcU6&index=7&t=26s)**, **[EA Desktop](https://youtu.be/BxUL27qVgaU?list=PLsSFD61FiOVmAwChPSrIFkjDLoLsyqcU6)**, **Escape from Tarkov**, **GeForce Now**, GOG Galaxy, **[Genshin Impact](https://youtu.be/WFt5DvKQ7pc?list=PLsSFD61FiOVmAwChPSrIFkjDLoLsyqcU6)**,  GeForce Now, Honkai StarRail, Magic Arena,  **[Origin](https://youtu.be/qRYra_fQt0I?list=PLsSFD61FiOVmAwChPSrIFkjDLoLsyqcU6)**, **OBS Studio**, Oculus, PS Remote Play, **Riot Games** ([Valorant](https://youtu.be/QyRwR7DbjQs?list=PLsSFD61FiOVmAwChPSrIFkjDLoLsyqcU6), League...), Rockstar, **[Steam](https://youtu.be/rLXGs1Yr3m8?list=PLsSFD61FiOVmAwChPSrIFkjDLoLsyqcU6)**, and **[Ubisoft Connect](https://youtu.be/XKBkIQaJzOA?list=PLsSFD61FiOVmAwChPSrIFkjDLoLsyqcU6)** - [YouTube Playlist](https://www.youtube.com/playlist?list=PLsSFD61FiOVmAwChPSrIFkjDLoLsyqcU6)
	
*This list may not be up-to-date - As we can add more easily in a simple text file - `Platforms.json`. If you'd like to learn more, see this [Wiki page](https://github.com/TCNOco/TcNo-Acc-Switcher/wiki/Help-code-a-platform).

[TcNo Account Switcher Install Guide](https://www.youtube.com/watch?v=sjJ8OZ_urJY&list=PLsSFD61FiOVmAwChPSrIFkjDLoLsyqcU6&index=1&t=27s)

**Featuring**
-  **Better UI**, with animations. Fully user/community customisable **theme system**. 5 Themes built in (so far).
-   **Streamer mode** to hide SteamIDs and more while Stream software is running (ie OBS, XSplit...)
-   **Automatic updates** WAY smaller updates, due to using a new Patch system. No more redownloading the entire app. Only a few KB/MB at a time.
-  **Steam: Log in as Invisible, Offline and more!** Copy profile links, SteamID, VAC info and create quick-switch desktop shortcuts!
- **Easily add & customize new platforms** since version 5.0 (Jan 2022).
- **Control via Tray** for quick-switching without keeping it all open.
- **Protocol support** to easily build access via other tools (`tcno:\\\<command>`) [CLI & Protocol Wiki](https://github.com/TCNOco/TcNo-Acc-Switcher/wiki/CLI-&-Protocol)

\[For info on how any of these work, see the [Wiki](https://github.com/TCNOco/TcNo-Acc-Switcher/wiki)]

### Lost? Visit the [Wiki](https://github.com/TCNOco/TcNo-Acc-Switcher/wiki) for more info

## Installation:
#### Install Guide
<p align="center">
	<a href="https://youtu.be/sjJ8OZ_urJY">
	    <img alt="Website" src="https://i.imgur.com/izr2mKn.png" target="_blank" height=300">
	</a>
</p>
    
1. Download `TcNo Account Switcher Installer.exe`
2. Run the installer, and the application should launch when done.

Want a portable install? Download and run `TcNo-Acc-Switcher.exe` directly (Do see info and steps on the [portable installs wiki page](https://github.com/TCNOco/TcNo-Acc-Switcher/wiki#portable-eg-for-usb))

## Screenshots

<p>
<a href="https://imgur.com/a/5E8qkmS">
<h4>Platforms</h4>
  <img alt="Main window screenshot" src="https://i.imgur.com/W45WLq7.png" width=773">
<h4>Steam account switcher</h4>
  <img alt="Steam account switcher" src="https://i.imgur.com/OtJzRAz.png" width=773">
<h4>Advanced cleaning and settings</h4>
  <img alt="Combined image of multiple pages" src="https://i.imgur.com/Ob4C80c.png" width=773">
<h4>Now with Shortcuts for games</h4>
  <img alt="Game and platform shortcuts" src="https://user-images.githubusercontent.com/10319195/149788470-009e3861-6b8a-4858-8dab-5549b0564a2f.gif" width=773">
</a>
</p>

#### Special Thanks

<table>
  <tr>
    <td><a href="https://signpath.io/?utm_source=foundation&utm_medium=github&utm_campaign=tcno-acc-switcher"><img src="https://signpath.org/assets/favicon-50x50.png" alt="SignPath" width="32" /></a></td>
    <td>Free code signing on Windows provided by <a href="https://signpath.io/?utm_source=foundation&utm_medium=github&utm_campaign=tcno-acc-switcher">SignPath.io</a>, certificate by <a href="https://signpath.org/?utm_source=foundation&utm_medium=github&utm_campaign=tcno-acc-switcher">SignPath Foundation</a></td>
  </tr>
</table>

#### [Privacy Policy](https://github.com/TCNOco/TcNo-Acc-Switcher/blob/master/PRIVACY.md)

#### Disclaimer

```
All trademarks and materials are the property of their respective owners and their licensors. This project is not affiliated
with any companies referenced. This is not "Official" software or related to any companies mentioned. All it does is let you
move your files around on your computer the same way you can. The use of names, icons and trademarks does not indicate
endorsement of the trademark holder by this project or its creators, nor vice versa. They are only used to visually indicate
which programs this project interacts with easily to the end-user.

By enabling optional features that scrape the web for publically available information (such as limited game/profile statistics
and other data), you understand and accept full responsibility for doing so on your own volition. If you appreciate accurate
information, support the services providing it directly. The information collected is incredibly limited and is no replacement
or competitor for sites scraped.

I am not responsible for the contents of external links.
For the rest of the disclaimer, refer to the License (GNU General Public License v3.0) file:
https://github.com/TCNOCo/TcNo-Acc-Switcher/blob/master/LICENSE - See sections like 15, 16 and 17, as well as GitHub's
'simplification' at the top of the above website.
```
